export class User{
  id: number = 0;
  userName: string = "";
  password: string = "";
  firstName: string = "";
  lastName: string = "";
  phone: string = "";
  email: string = "";
  isReviewer: boolean = false;
  isAdmin: boolean = false;


}
